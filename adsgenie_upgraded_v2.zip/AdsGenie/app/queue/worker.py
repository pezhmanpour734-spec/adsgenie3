import asyncio, re
from app.config import settings

class InstanceQueue:
    def __init__(self, instance_id):
        self.instance_id=instance_id
        self.paused_until=0

    async def run(self, jobs, send):
        # jobs must already be explicitly authorized/postable.
        for start in range(0,len(jobs),settings.batch_size):
            batch=jobs[start:start+settings.batch_size]
            for job in batch:
                try:
                    await send(job)
                except Exception as exc:
                    msg=str(exc)
                    m=re.search(r"FLOOD_WAIT[_ ](\d+)",msg)
                    if m:
                        await asyncio.sleep(int(m.group(1)))
                        continue
                    raise
                await asyncio.sleep(settings.min_delay_seconds)
            if start+settings.batch_size < len(jobs):
                await asyncio.sleep(settings.batch_cooldown_seconds)
