from pathlib import Path
from telethon import TelegramClient
from sqlalchemy import select
from app.config import settings
from app.db import Session, Account

async def login_instance(instance_id:int):
    async with Session() as s:
        acc=(await s.execute(select(Account).where(Account.instance_id==instance_id))).scalar_one_or_none()
        if not acc:
            print("Account record not found. Create the instance first."); return
        session=Path(acc.session_path)
    session.parent.mkdir(parents=True,exist_ok=True)
    client=TelegramClient(str(session), settings.api_id, settings.api_hash)
    phone=input("Phone number for THIS account (initial authentication only): ").strip()
    await client.start(phone=phone)
    me=await client.get_me()
    async with Session() as s:
        acc=(await s.execute(select(Account).where(Account.instance_id==instance_id))).scalar_one()
        acc.telegram_user_id=me.id
        acc.phone_hint=phone[-4:] if len(phone)>=4 else ""
        acc.first_name=me.first_name or ""
        acc.username=me.username or ""
        acc.authenticated=True
        await s.commit()
    print(f"Authenticated instance #{instance_id}: @{me.username or 'no_username'}")
    await client.disconnect()

    # Import the operator-approved target list after authentication.
    # No chats are auto-joined; only already-joined targets are considered.
    try:
        from app.mtproto.targets import sync_targets
        await sync_targets(instance_id)
    except Exception as exc:
        print(f"⚠️ Approved-target sync failed: {type(exc).__name__}: {exc}")

    # If the systemd template is installed, keep this controller online after
    # the terminal closes and across VPS reboots. Otherwise the normal CLI
    # background manager remains available.
    try:
        from app.process_manager import start
        start(instance_id)
    except Exception as exc:
        print(f"⚠️ Controller auto-start skipped: {type(exc).__name__}: {exc}")


async def replace_instance_account(instance_id: int):
    """Explicit replacement entry point for a legitimate new MTProto account."""
    return await login_instance(instance_id)
