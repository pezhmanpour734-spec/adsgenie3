import asyncio
import os
from pathlib import Path
from contextlib import asynccontextmanager

_locks = {}
_registry_lock = asyncio.Lock()

async def _get_lock(key: str):
    async with _registry_lock:
        return _locks.setdefault(key, asyncio.Lock())

@asynccontextmanager
async def session_lock(session_path: str):
    """Serialize Telethon SQLite-session access within and across processes."""
    key = str(Path(session_path).resolve())
    alock = await _get_lock(key)
    async with alock:
        lock_path = Path(key + ".adsgenielock")
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        fh = open(lock_path, "a+b")
        try:
            if os.name == "nt":
                import msvcrt
                while True:
                    try:
                        fh.seek(0)
                        msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
                        break
                    except OSError:
                        await asyncio.sleep(0.15)
            else:
                import fcntl
                while True:
                    try:
                        fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                        break
                    except BlockingIOError:
                        await asyncio.sleep(0.15)
            yield
        finally:
            try:
                if os.name == "nt":
                    import msvcrt
                    fh.seek(0)
                    msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
            finally:
                fh.close()
