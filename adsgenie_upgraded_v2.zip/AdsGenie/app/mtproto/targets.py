"""Sync an operator-supplied Telegram target list without auto-joining.

Only destinations the MTProto account already belongs to are considered.
The list is an allowlist, not an auto-join queue. Posting permission and the
persistent Stars/no-permission blacklist are checked before a destination is
enabled for campaigns.
"""
from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy import select
from telethon import TelegramClient
from telethon.tl.types import Channel, Chat

from app.config import PROJECT_ROOT, settings
from app.db import Session, Account, Destination
from app.mtproto.session_lock import session_lock
from app.services.destination_filter import load_blacklist

TARGET_FILE = Path(settings.target_list_path)


def load_targets() -> set[str]:
    if not TARGET_FILE.exists():
        return set()
    values = set()
    for raw in TARGET_FILE.read_text(encoding="utf-8").splitlines():
        value = raw.strip().lstrip("@").lower()
        if value and not value.startswith("#"):
            values.add(value)
    return values


def _category(entity) -> str:
    if isinstance(entity, Channel):
        if getattr(entity, "forum", False):
            return "FORUMS"
        if getattr(entity, "broadcast", False):
            return "CHANNELS"
        return "GROUPS"
    if isinstance(entity, Chat):
        return "GROUPS"
    return "OTHER"


async def _can_post(client: TelegramClient, entity) -> bool:
    try:
        perms = await client.get_permissions(entity, "me")
        if isinstance(entity, Channel) and getattr(entity, "broadcast", False):
            return bool(getattr(perms, "post_messages", False))
        return bool(getattr(perms, "send_messages", True))
    except Exception:
        return False


async def sync_targets(instance_id: int):
    """Sync only allowlisted chats already joined by this account."""
    targets = load_targets()
    if not targets:
        print(f"No usernames found in {TARGET_FILE}. Nothing to sync.")
        return

    async with Session() as s:
        acc = (await s.execute(select(Account).where(Account.instance_id == instance_id))).scalar_one_or_none()
    if not acc or not acc.authenticated:
        print("MTProto account is not authenticated.")
        return

    client = TelegramClient(acc.session_path, settings.api_id, settings.api_hash)
    async with session_lock(acc.session_path):
        await client.connect()
        try:
            if not await client.is_user_authorized():
                print("MTProto session is no longer authorized. Re-login this instance.")
                return
            print(f"Syncing {len(targets)} approved usernames; no chats will be auto-joined.")
            dialogs = await client.get_dialogs()
            joined_by_username = {
                (getattr(d.entity, "username", "") or "").lower(): d
                for d in dialogs
                if isinstance(d.entity, (Channel, Chat))
            }
            blacklisted_ids = load_blacklist(instance_id)
            checked = added = eligible = missing = cached_skips = 0
            async with Session() as db:
                for username in sorted(targets):
                    dialog = joined_by_username.get(username)
                    if not dialog:
                        missing += 1
                        continue
                    entity = dialog.entity
                    category = _category(entity)
                    if category not in {"GROUPS", "FORUMS", "CHANNELS"}:
                        continue
                    row = (await db.execute(select(Destination).where(
                        Destination.instance_id == instance_id,
                        Destination.chat_id == dialog.id,
                    ))).scalar_one_or_none()
                    if str(dialog.id) in blacklisted_ids:
                        cached_skips += 1
                        if row:
                            row.authorized = False; row.can_post = False; row.enabled = False
                        continue
                    can_post = await _can_post(client, entity)
                    checked += 1
                    if not row:
                        row = Destination(
                            instance_id=instance_id,
                            chat_id=dialog.id,
                            title=dialog.name or "",
                            username=getattr(entity, "username", "") or "",
                            category=category,
                        )
                        db.add(row); added += 1
                    row.title = dialog.name or row.title or ""
                    row.username = getattr(entity, "username", "") or ""
                    row.category = category
                    row.authorized = bool(can_post)
                    row.can_post = bool(can_post)
                    row.enabled = bool(can_post)
                    row.last_checked_at = datetime.now(timezone.utc)
                    if can_post and category in {"GROUPS", "FORUMS"}:
                        eligible += 1
                await db.commit()
            print(
                f"Sync complete. Checked: {checked}; new records: {added}; "
                f"eligible Groups/Forums: {eligible}; missing/unjoined: {missing}; "
                f"saved blacklist skips: {cached_skips}."
            )
        finally:
            await client.disconnect()
